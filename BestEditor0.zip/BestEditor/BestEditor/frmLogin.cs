﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace BestEditor
{
    public partial class Login : Form
    {  //连接数据字符串声明        
        string str_con = "initial catalog=notepad;data source=.;Integrated Security=true";       //声明一个数据集        
        DataSet ds = new DataSet();
        SqlDataAdapter da;
        SqlConnection con;
        public Login()
        {
            InitializeComponent();

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string str_Login = "select name,password from login where name='" + txtUser.Text.Trim() + "' and password='" + txtPassWord.Text.Trim() + "'";
                con = new SqlConnection(str_con);
                con.Open();
                da = new SqlDataAdapter(str_Login, con);
                da.Fill(ds);//如果记录大于0说明输入用户与密码存在正确,则登录成功                
                if (ds.Tables[0].Rows.Count > 0)
                {
                    MessageBox.Show("登录成功");//这可以自己发挥,写你想做事件啊  
                    Main adminform = new Main(); //窗口作为类使用
                    this.Hide(); //隐藏当前userlogin窗口
                    adminform.Show(); //显示admin管理窗口

                }
                else
                {
                    MessageBox.Show("登录失败，请重新输入用户与密码", "提示信息", MessageBoxButtons.OKCancel, MessageBoxIcon.Stop);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                ds.Clear();
                con.Close();
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReg_Click(object sender, EventArgs e)
        {
            if (txtUser.Text.Trim() == "")
            {
                lblInfo.Text = "姓名不能为空！请输入姓名。";
                txtUser.Focus();
                btnReg.Enabled = false;
                return;
            }
            if (txtPassWord.Text.Trim() == "")
            {

                lblInfo.Text = "密码不能为空！请输入密码。";
                txtPassWord.Focus();
                btnReg.Enabled = false;
                return;
            }
            else
            {
                btnReg.Enabled = true;
            }
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = str_con;
            cn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;

            {
                cmd.CommandText = "Insert Into login(name, password) Values('" + txtUser.Text.Trim() + "','" + txtPassWord.Text.Trim() + "')";

                int i = cmd.ExecuteNonQuery();
                if (i > 0)
                {
                    lblInfo.Text = "注册成功！";
                }
                else
                {
                    lblInfo.Text = "注册失败！";
                }

            }
        }
    }
}

